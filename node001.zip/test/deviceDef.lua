if mqttClient == nil then
    require("device")
end

if modbusM == nil then
    --modbusM = require('modbusModule')
    --modbusM.connectModbus("192.168.199.134" , 5552 , 1 , 5 , 3)
    --modbusM.connectModbus("192.168.1.104" , 5552 , 1 , 5 , 3)
    --backEnd = modbusM;
end

brokerConfs = {addr=os.getenv("MQTT_BROKER_HOST") , port=tonumber(os.getenv("MQTT_BROKER_PORT")) , userName="defUser" , password="testpass"}
--brokerConfs = {addr="192.168.1.102" , port=1883}

watchDevices = {"device200" , "device201", "device202", "device203", "device204", "device205"}

function initDevice()
    --[[
    local switchs = {"switch1" , "switch2" , "switch3" , "switch4" , "switch5" , "switch6" , "switch7" , "switch8" , "switch9" ,"switch10" }
    registerPropGroup("switch" , switchs , modbusM.AO , 0 , modbusM.READ_WRITE)
    --registerProp("switch1" , modbusM.AO , 0 , modbusM.READ_WRITE)
    --registerProp("switch2" , modbusM.AO , 1 , modbusM.READ_WRITE)
    --registerProp("switch3" , modbusM.AO , 2 , modbusM.READ_WRITE)
    --registerProp("switch4" , modbusM.AO , 3 , modbusM.READ_WRITE)
    --registerProp("switch5" , modbusM.AO , 4 , modbusM.READ_WRITE)
    --registerProp("switch6" , modbusM.AO , 5 , modbusM.READ_WRITE)
    --registerProp("switch7" , modbusM.AO , 6 , modbusM.READ_WRITE)
    --registerProp("switch8" , modbusM.AO , 7 , modbusM.READ_WRITE)
    --registerProp("switch9" , modbusM.AO , 8 , modbusM.READ_WRITE)
    --registerProp("switch10" , modbusM.AO , 9 , modbusM.READ_WRITE)


    registerProp("AI1" , modbusM.AI , 0 , modbusM.READ)
    registerProp("AI2" , modbusM.AI , 2 , modbusM.READ)
    registerProp("AI3" , modbusM.AI , 4 , modbusM.READ)
    registerProp("AI4" , modbusM.AI , 6 , modbusM.READ)
    registerProp("AI5" , modbusM.AI , 8 , modbusM.READ)


    registerProp("status1" , modbusM.DI , 0 , modbusM.READ)
    registerProp("status2" , modbusM.DI , 1 , modbusM.READ)
    registerProp("status3" , modbusM.DI , 2 , modbusM.READ)
    registerProp("status4" , modbusM.DI , 3 , modbusM.READ)
    registerProp("status5" , modbusM.DI , 4 , modbusM.READ)
    registerProp("status6" , modbusM.DI , 5 , modbusM.READ)
    registerProp("status7" , modbusM.DI , 6 , modbusM.READ)
    registerProp("status8" , modbusM.DI , 7 , modbusM.READ)
    registerProp("status9" , modbusM.DI , 8 , modbusM.READ)
    registerProp("status10" , modbusM.DI , 9 , modbusM.READ)


    registerProp("DO1" , modbusM.DO , 0 , modbusM.READ_WRITE)
    registerProp("DO2" , modbusM.DO , 2 , modbusM.READ_WRITE)
    registerProp("DO3" , modbusM.DO , 4 , modbusM.READ_WRITE)
    registerProp("DO4" , modbusM.DO , 6 , modbusM.READ_WRITE)
    registerProp("DO5" , modbusM.DO , 8 , modbusM.READ_WRITE)
  ]]
end

function readDeviceProps()
    --[[
	local random = math.random()

	if random > 0.5 then
		random = true;
	else
		random = false;
	end
    
    setPropGroup("switch", {false,true,true,true,true,true,true,true,true,false});
    getPropGroup("switch");

	for a=1,10,1 do

	    getProp("status"..a)
    end

    for a=1,5,1 do
	    getProp("AI"..a)
	    setProp("DO"..a , 355)
	    getProp("DO"..a)
    end
    ]]
    
	for a=1,10,1 do  
    	local random = math.random()
    
    	if random > 0.5 then
    		random = 1;
    	else
    		random = 0;
    	end
	    device["switch"..a] = random
	    device["status"..a] = random
    end

    for a=1,5,1 do  
    	device["AI"..a] = math.random() * 100
    	device["DO"..a] = 4356
    end
    
    device["timestamp"] = os.time()
end

startDevice()